# Quick Start Guide

## Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
Create a `.env` file in the root folder with:
```env
PORT=3000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_secret_key_here
JWT_EXPIRE=7d
```

**Get free MongoDB:**
1. Go to https://mongodb.com/atlas
2. Create free account → Create free cluster
3. Click "Connect" → "Connect your application"
4. Copy connection string and replace `<password>` with your password

### 3. Start the Server
```bash
npm start
```
Or for development (auto-restart on changes):
```bash
npm run dev
```

### 4. Test the API
Open browser: http://localhost:3000

## API Endpoints Summary

| Action | Method | Endpoint |
|--------|--------|----------|
| Register | POST | `/api/auth/signup` |
| Login | POST | `/api/auth/login` |
| Create Project | POST | `/api/projects` |
| Add Team Member | POST | `/api/projects/:id/members` |
| Create Task | POST | `/api/tasks` |
| Update Task | PUT | `/api/tasks/:id` |
| Dashboard | GET | `/api/dashboard` |

## Test with Postman/curl

### Register
```bash
curl -X POST http://localhost:3000/api/auth/signup -H "Content-Type: application/json" -d "{\"name\":\"John\",\"email\":\"john@test.com\",\"password\":\"123456\"}"
```

### Login
```bash
curl -X POST http://localhost:3000/api/auth/login -H "Content-Type: application/json" -d "{\"email\":\"john@test.com\",\"password\":\"123456\"}"
```

Use the token from login response in Authorization header:
```
Authorization: Bearer YOUR_TOKEN_HERE
```
